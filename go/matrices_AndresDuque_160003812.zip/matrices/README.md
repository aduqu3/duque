### Tarea matrices materia go Unillanos  

**Andres Alejandro Duque T. 160003812**

- 4 Ejercicios resueltos de matrices